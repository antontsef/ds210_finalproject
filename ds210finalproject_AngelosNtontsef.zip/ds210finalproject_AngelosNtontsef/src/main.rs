extern crate csv;

use graph::prelude::*;
use std::fs::File;
use std::io::BufReader;
use csv::Reader;
use std::collections::HashMap;
use std::error::Error;
use std::str::Split;
use csv;
use serde::Deserialize;
use std::env;

mod graph;

mod short_path;

// main function
fn main() {
    // list of file paths
    let filenames = vec!["airlines.csv", "airplanes.csv", "airports.csv", "routes.csv"];

    // iteraitng over each file
    for filename in filenames {
        println!("reading file: {}", filename);

        // opening + reading the csv file
        let file = File::open(filename).expect("Failed to open file");
        let buf_reader = BufReader::new(file);

        let mut reader = Reader::from_reader(buf_reader);

        let mut values: Vec<(VertexId,VertexId)> = Vec::new();

        for line_error in io::BufReader::new(file).lines() {
            if let Ok(line) = line_error {
                let mut splitted = line.split(' ');
                let v0 = splitted.nth(0).unwrap().parse::<usize>().unwrap();
                let v1 = splitted.nth(0).unwrap().parse::<usize>().unwrap();
                
                values.push((v0,v1));
            }
        }

        // iterating over each record in the csv file
        for result in reader.records() {
            // extracting
            let record = result.expect("Error reading CSV record");
            
            // processing
            let record_int: Vec<i32> = record
                .iter()
                // converts fields to i32 or 0 if conversion fails
                .map(|field| field.parse::<i32>().unwrap_or(0))
                .collect();
        }
        println!("finished reading file: {}", filename);
    }

    //creating graph
    let graph = GraphUndirected::from_ids(values.as_slice());

    //creating neighbors
    let outneighbors_1 = graph.vertices_outneighbors_1();
	let outneighbors_2 = graph.vertices_outneighbors_2();
	
	let sorted_keys: Vec<&VertexId> = graph.vertex_data.keys().sorted().collect();

    println!("Outneighbors of vertices:");
	for key in &keys_sorted {
		println!("\tvertex {}:",key);
		
        //calculating degree of neighbors
		let n_1 = outneighbors_1.get(key).unwrap();
		let n_2 = outneighbors_2.get(key).unwrap();
		
		println!("\t\tDegree of neighbors at distance 1: {}",n_1);
		println!("\t\tDegree of neighbors at distance 2: {}",n_2);
		
		//if the number of neighbors is one or zero, it is not considered
		if *n_1 > 1 && *n_2 > 1 {
			let power = (*n_2 as f64).log(*n_1 as f64);
			println!("\t\tpower is: {}",power);
			
			powers.push(power);
		}
		else {
			println!("\t\t-");
		}
	}
}