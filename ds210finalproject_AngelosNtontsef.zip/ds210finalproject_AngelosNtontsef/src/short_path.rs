use std::fs::File;
use std::io::{self,BufRead};

use std::collections::HashMap;

use itertools::Itertools;


type VertexId = usize;

//shortest paths module

mod graph;

pub mod short_path {
    //counts the neighbors at distance = 1
    fn vertices_outneighbors_1(&self)->HashMap<VertexId,usize> {
        HashMap::from_iter(
            self.vertex_data.iter()
                .map(|(key,value)| {
                    (*key,value.len())
                })
        )
    }

    //counts the neighbors at distance = 2
	fn vertices_outneighbors_2(&self)->HashMap<VertexId,usize> {
		HashMap::from_iter(
			self.vertex_data.iter()
				.map(|(key,value)| {
					let num = value.iter()
						.map(|k| {
							self.vertex_data.get(k).unwrap().len()
						})
						.sum();
					
					(*key,num)
				})
		)
	}
}