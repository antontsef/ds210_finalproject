use std::fs::File;
use std::io::{self,BufRead};

use std::collections::HashMap;

use itertools::Itertools;


type VertexId = usize;


//graph module

pub mod graph {
    //graph struct using hashmap
    struct GraphUndirected {
        vertex_data: HashMap<VertexId,Vec<VertexId>>,
    }

    impl GraphUndirected {
        fn new()->Self { //returns empty
            Self {
                vertex_data: HashMap::new()
            }
        }
        
        fn get_ids(ids: &[(VertexId,VertexId)])->Self {
            let mut graph = Self::new();
            
            //iterating over the vertex_ids
            //adding a corresponding value when a new id is found
            for id in ids {
                if graph.vertex_data.contains_key(&id.0) {
                    if !graph.vertex_data.contains_key(&id.1) {
                        graph.vertex_data.insert(id.1,Vec::new());
                    }
                    graph.vertex_data.get_mut(&id.0).unwrap().push(id.1);
                }
                else { //adding value to vector if it already exists
                    graph.vertex_data.insert(id.0,vec![id.1]);
                }
            }
            
            graph
        }
        
        
    }
}